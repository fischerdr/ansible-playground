# Portworx Upgrade Role - Version 1.0.0

Production-ready Ansible role for automated Portworx cluster upgrades on OpenShift 4.18.

## Package Contents

```
portworx-upgrade-role-1.0.0/
├── README.md                    # This file
├── portworx_upgrade/            # The Ansible role
│   ├── README.md               # Role documentation
│   ├── defaults/               # Default variables
│   ├── vars/                   # Internal variables
│   ├── tasks/                  # Role tasks
│   │   ├── preflight/         # Preflight validation
│   │   ├── upgrade/           # Upgrade execution
│   │   ├── monitor/           # Progress monitoring
│   │   ├── validate/          # Final validation
│   │   └── report/            # Report generation
│   ├── handlers/               # Event handlers
│   ├── templates/              # Jinja2 templates
│   ├── filter_plugins/         # Custom Jinja2 filters
│   ├── tests/                  # Comprehensive test suite
│   ├── playbooks/              # Example playbook
│   ├── aap_import/             # AAP integration configs
│   └── files/                  # Version files
└── docs/                        # Documentation
    ├── DISTRIBUTION-README.md   # Distribution notes
    ├── QUICKSTART.md           # Quick start guide
    ├── portworx-upgrade-role-final.md  # Complete specification
    ├── monitoring-flow.md      # Monitoring flow documentation
    ├── portworx-upgrade-manual-v2.md   # Manual procedures
    └── example-playbook.yml    # Example playbook usage
```

## Quick Start

### 1. Extract to Ansible Project

```bash
tar -xzf portworx-upgrade-role-1.0.0.tar.gz
cp -r portworx-upgrade-role-1.0.0/portworx_upgrade /path/to/your/ansible/project/roles/
```

### 2. Install Dependencies

```bash
cd /path/to/your/ansible/project
ansible-galaxy collection install -r roles/portworx_upgrade/requirements.yml
```

### 3. Create Playbook

```yaml
---
- name: Upgrade Portworx cluster
  hosts: localhost
  gather_facts: true

  roles:
    - role: portworx_upgrade
      vars:
        portworx_target_version: "3.5.0"
        portworx_impatient_mode: false
```

### 4. Run Upgrade

```bash
ansible-playbook playbooks/px_upgrade.yml \
  -e portworx_target_version=3.5.0
```

## Features

- **Comprehensive Preflight Validation**: Nodes, pods, cluster status, StorageCluster configuration
- **Operator-Controlled Upgrade**: Triggers and monitors automatic rolling upgrade
- **Three-Tier Timeout System**:
  - Per-pod timeout (15-25 minutes)
  - Global timeout with sliding window (35 minutes)
  - Dual-mode: sliding window for active pods, inactivity detection for operator stalls
- **Impatient Mode**: Multi-batch acceleration for storageless pod upgrades
- **Safety Guarantees**: Storage pod protection, batch size limits, comprehensive validation
- **Extensive Monitoring**: Real-time pod classification, stuck detection, progress tracking
- **Final Validation**: Pod health, cluster health, version consistency checks
- **Detailed Reporting**: Upgrade summary with timing, pod transitions, and diagnostics

## Test Coverage

The role includes 7 comprehensive test suites (36 tests total):

1. Filter plugin storage classification (6 tests)
2. Storage pod detection label-based (5 tests)
3. Activity detection completion-based (5 tests)
4. Impatient mode multi-batch execution (7 tests)
5. Per-pod timeout logic (3 tests)
6. Node validation logic (6 tests)
7. Global timeout sliding window (4 tests)

Run tests:
```bash
cd roles/portworx_upgrade/tests
./run_all_tests.sh
```

## AAP/AWX Integration

The role includes AAP import configurations in `aap_import/`:

- Project configuration
- Execution environment
- Job templates (preflight, upgrade, impatient mode)
- Workflow template
- Import automation script

See `portworx_upgrade/aap_import/README.md` for details.

## Documentation

- **Role README**: `portworx_upgrade/README.md` - Complete role documentation
- **Specification**: `docs/portworx-upgrade-role-final.md` - Full requirements and design
- **Monitoring Flow**: `docs/monitoring-flow.md` - Detailed monitoring documentation
- **Manual Procedures**: `docs/portworx-upgrade-manual-v2.md` - Step-by-step manual guide
- **Quick Start**: `docs/QUICKSTART.md` - Getting started guide
- **Distribution**: `docs/DISTRIBUTION-README.md` - Distribution and packaging notes

## Requirements

- Ansible Core 2.18.4+
- Python 3.11+
- OpenShift 4.18
- Collections:
  - kubernetes.core 2.3.0+
  - ansible.posix
  - ansible.utils

## Variables

Key variables (see `portworx_upgrade/defaults/main.yml` for complete list):

```yaml
portworx_target_version: ""          # REQUIRED: Target version (e.g., "3.5.0")
portworx_namespace: "portworx"       # Portworx namespace
portworx_impatient_mode: false       # Enable storageless acceleration
portworx_detailed_logging: true      # Enable detailed logs
portworx_global_inactivity_timeout: 2100  # 35 minutes
portworx_pod_upgrade_timeout: 1500   # 25 minutes
```

## Version History

- **1.0.0** (2025-12-14): Initial production release
  - Complete preflight validation
  - Operator-controlled upgrade with monitoring
  - Dual-mode global timeout (sliding window)
  - Impatient mode multi-batch execution
  - Comprehensive test coverage (36 tests)
  - Full AAP/AWX integration
  - Complete documentation (sanitized for distribution)

## License

See LICENSE file in the portworx_upgrade directory.
