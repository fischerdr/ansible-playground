# Security Guidelines for Using HashiCorp Vault with Ansible Playbooks

## Introduction

This comprehensive security guide provides detailed best practices for integrating HashiCorp Vault with Ansible automation workflows in enterprise environments. As organizations increasingly adopt Infrastructure as Code (IaC) approaches, the secure management of secrets becomes critical to maintaining robust security postures while enabling automation.

HashiCorp Vault serves as a centralized secrets management platform that, when properly configured with Ansible, creates a secure and scalable solution for managing credentials, certificates, API keys, and other sensitive information across diverse infrastructure environments. This document addresses the complete security lifecycle of this integration, from initial architecture design to ongoing operational security.

### Purpose and Scope

This guide is intended for:

- DevOps engineers responsible for Ansible automation
- Security professionals overseeing secrets management
- System administrators managing infrastructure credentials
- Compliance officers ensuring adherence to security standards

The recommendations outlined here are applicable to both on-premises and cloud-based deployments, with special considerations for hybrid environments.

### Key Topics Covered

This document provides detailed guidance on:

1. **Role-Based Access Control (RBAC)** - Implementing granular access control using Active Directory groups, with specific policies for different roles and responsibilities.

2. **Host and User Access Restrictions** - Limiting Vault access to specific hosts and users through IP allowlisting, TLS client certificates, and multi-factor authentication.

3. **Namespace and Path Layout** - Organizing Vault namespaces and paths for optimal security, scalability, and manageability, with policy structures for different access levels.

4. **Ansible Tower/RHAAP Security** - Securing centralized automation platforms with proper authentication, authorization, credential management, and job template security controls.

5. **Enhanced Audit Capabilities** - Implementing comprehensive audit logging through callback plugins, centralized log collection, secure log management, and security tool integration.

6. **Execution Environment Security** - Securing containerized Ansible environments using minimal base images, vulnerability scanning, and least-privilege principles.

7. **Ansible Vault Integration** - Combining Ansible Vault with HashiCorp Vault for layered security, with practical implementation examples.

8. **Dynamic Secrets Management** - Leveraging Vault's dynamic secret capabilities for just-in-time access to databases, cloud providers, and SSH keys.

9. **Secret Rotation and Lifecycle** - Implementing automated secret rotation strategies with zero downtime approaches.

10. **Audit Logging and Monitoring** - Configuring comprehensive audit trails for security oversight and compliance reporting.

11. **Disaster Recovery Planning** - Ensuring availability of secrets during outages through proper backup, replication, and recovery procedures.

By following these guidelines, organizations can establish a secure, compliant, and operationally efficient secrets management framework that supports modern automation practices while maintaining strong security boundaries.

## Role-Based Access Control with AD Groups

To enforce granular access control, Vault policies should be mapped to AD groups. This ensures that only authorized users and systems can access the appropriate secret paths.

### AD Group Structure

1. **Ansible_DevOps** – Read-only access to non-production secrets.
2. **Ansible_ProdOps** – Read-only access to production secrets.
3. **Ansible_Admins** – Full access to all secrets and administrative capabilities.
4. **Ansible_Auditors** – Read-only access for audit purposes.

### Example KV Path Permissions

Vault policies should enforce least privilege access:

| Vault Path                   | AD Group            | Access Type  |
|------------------------------|---------------------|-------------|
| `secret/ansible/dev/*`       | Ansible_DevOps     | read        |
| `secret/ansible/prod/*`      | Ansible_ProdOps    | read        |
| `secret/ansible/global/*`    | Ansible_DevOps, Ansible_ProdOps | read |
| `secret/ansible/admin/*`     | Ansible_Admins     | read, write |
| `secret/ansible/audit/*`     | Ansible_Auditors   | read        |

### Vault Policy Example for AD Groups

```hcl
path "secret/ansible/dev/*" {
  capabilities = ["read"]
  allowed_entities = ["group=Ansible_DevOps"]
}

path "secret/ansible/prod/*" {
  capabilities = ["read"]
  allowed_entities = ["group=Ansible_ProdOps"]
}

path "secret/ansible/admin/*" {
  capabilities = ["read", "write"]
  allowed_entities = ["group=Ansible_Admins"]
}
```

## Restricting Vault Access to Specific Hosts and Users

To further secure Vault access, restrictions should be applied at the host and user level.

### Host-Based Access Control

Vault should be configured to allow access only from approved hosts running Ansible. This can be achieved using:

- **IP Allowlisting**
- **TLS Client Certificates**
- **Authenticated Vault Agents on Managed Nodes**

#### Example CIDR Restriction Policy

```hcl
path "secret/ansible/prod/*" {
  capabilities = ["read"]
  allowed_entities = ["group=Ansible_ProdOps"]
  allowed_bound_cidrs = ["10.1.1.0/24"]
}
```

### Restricting Login IPs with Identity Group Constraints

If you are using an identity-based authentication method like LDAP or OIDC, you can enforce **bound CIDRs** at the authentication level.

#### Example for LDAP Authentication

```hcl
auth "ldap" {
  allowed_entities = ["group=Ansible_DevOps"]
  bound_cidrs = ["192.168.1.0/24"]
}
```

### Using TLS Client Certificates for Host Restrictions

For environments using **TLS authentication**, Vault can be configured to require client certificates tied to specific hosts.

#### Example TLS Authentication

```hcl
auth "cert" {
  allowed_certs = ["CN=ansible-node1.example.com"]
}
```

- This ensures that only `ansible-node1.example.com` can authenticate using TLS certificates.

### Dynamic Host Restrictions with Vault Agent Auto-Auth

If using **Vault Agent with Auto-Auth**, you can tie access to specific hosts by requiring **AppRole secret IDs** to be tied to the machine’s metadata (like AWS IAM role, Kubernetes service account, or machine identity).

#### Example for AppRole with Host Metadata Binding

```hcl
auth "approle" {
  allowed_entity_aliases = ["host-ansible-prod"]
}
```

- The secret ID can only be retrieved from pre-approved hosts.

### Enforcing MFA for Untrusted Locations

For additional security, configure **MFA rules** to require second-factor authentication when users are accessing Vault from outside an approved network.

#### Example MFA Policy

```hcl
path "auth/ldap/login" {
  capabilities = ["update"]
  mfa_policy = "mfa_required"
}
```

- MFA is enforced only when users try to authenticate from untrusted hosts.

## Vault Namespace and Path Layout Best Practices

Organizing Vault namespaces and paths effectively is crucial for security, scalability, and manageability. HashiCorp Vault's namespace feature (available in Enterprise) provides multi-tenancy capabilities, while path structure determines how secrets are organized within each namespace.

### Namespace Hierarchy Best Practices

Namespaces should follow a hierarchical structure that mirrors your organization:

1. **Root Namespace** - Reserved for global administrators only
2. **Organization-Level Namespaces** - For business units or departments
3. **Project-Level Namespaces** - For specific applications or environments
4. **Team-Level Namespaces** - For development, operations, or security teams

#### Example Namespace Structure

```text
root/
├── infrastructure/
│   ├── network/
│   ├── compute/
│   └── storage/
├── applications/
│   ├── frontend/
│   ├── backend/
│   └── database/
└── security/
    ├── compliance/
    └── audit/
```

### Path Layout Best Practices

Within each namespace, organize paths according to these principles:

1. **Environment Segmentation** - Separate production, staging, and development secrets
2. **Functional Grouping** - Group secrets by their function or type
3. **Application Boundaries** - Isolate secrets by application or service
4. **Secret Type Separation** - Use different mount points for different secret types

#### Recommended Path Structure for Ansible

```text
secret/                           # KV secrets engine mount
├── ansible/                      # Ansible-specific secrets
│   ├── environments/             # Environment-specific secrets
│   │   ├── production/           # Production environment
│   │   │   ├── app1/             # Application-specific secrets
│   │   │   │   ├── credentials/  # Login credentials
│   │   │   │   ├── certificates/ # TLS certificates
│   │   │   │   └── config/       # Configuration secrets
│   │   │   └── app2/
│   │   ├── staging/
│   │   └── development/
│   ├── global/                   # Cross-environment secrets
│   │   ├── api_keys/             # Shared API keys
│   │   └── certificates/         # Global certificates
│   └── infrastructure/           # Infrastructure secrets
│       ├── network/              # Network device credentials
│       ├── cloud/                # Cloud provider credentials
│       └── databases/            # Database credentials
└── shared/                       # Shared secrets across teams
    └── common_services/          # Common service credentials
```

For dynamic secrets, use dedicated secret engines with appropriate paths:

```text
database/                         # Database secrets engine
├── roles/
│   ├── readonly/                 # Read-only database access
│   ├── readwrite/                # Read-write database access
│   └── admin/                    # Administrative database access
└── config/
    ├── postgres/                 # PostgreSQL connection configuration
    └── mysql/                    # MySQL connection configuration

pki/                             # PKI secrets engine for certificates
├── roles/
│   ├── web-server/              # Web server certificates
│   └── internal-services/       # Internal service certificates
└── config/
```

### Policy Structure for Different Levels

Policies should be designed to match your namespace and path hierarchy, following the principle of least privilege:

#### 1. Global Administrator Policies

For root-level administrators with broad access:

```hcl
# global-admin-policy.hcl
path "sys/*" {
  capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}

path "+/*" {
  capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}
```

#### 2. Namespace Administrator Policies

For administrators of specific namespaces:

```hcl
# namespace-admin-policy.hcl
path "sys/namespaces/applications/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

path "applications/*" {
  capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}
```

#### 3. Environment-Specific Policies

For managing secrets within specific environments:

```hcl
# prod-admin-policy.hcl
path "secret/ansible/environments/production/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

# prod-readonly-policy.hcl
path "secret/ansible/environments/production/*" {
  capabilities = ["read", "list"]
}
```

#### 4. Application-Specific Policies

For applications that need access to their own secrets:

```hcl
# app1-policy.hcl
path "secret/ansible/environments/+/app1/*" {
  capabilities = ["read"]
}

path "secret/ansible/global/*" {
  capabilities = ["read"]
}
```

#### 5. Function-Specific Policies

For teams with specific functional responsibilities:

```hcl
# database-team-policy.hcl
path "secret/ansible/*/databases/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

path "database/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}
```

### Policy Templates for Ansible Integration

For Ansible automation, create templated policies that can be applied consistently:

```hcl
# ansible-automation-policy.hcl
path "secret/ansible/environments/{{environment}}/{{application}}/*" {
  capabilities = ["read"]
}

path "secret/ansible/global/*" {
  capabilities = ["read"]
}

path "database/creds/{{role}}" {
  capabilities = ["read"]
}
```

### Namespace and Path Delegation

Implement delegation to allow teams to manage their own secrets:

1. **Namespace Delegation** - Grant namespace creation and management capabilities to team leads
2. **Path Delegation** - Allow application owners to manage their specific secret paths
3. **Policy Delegation** - Enable teams to create and manage policies within their namespace

#### Example Delegation Policy

```hcl
# team-delegation-policy.hcl
path "sys/policies/acl/{{identity.entity.name}}-*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

path "auth/token/create" {
  capabilities = ["create", "update"]
  allowed_parameters = {
    "policies" = ["{{identity.entity.name}}-*"]
  }
}
```

### Namespace and Path Transition Strategy

When migrating to a new namespace and path structure:

1. **Dual-Write Period** - Write secrets to both old and new paths during transition
2. **Read-Only Legacy Paths** - Convert old paths to read-only during migration
3. **Path Redirection** - Use response wrapping or identity aliases to redirect requests
4. **Gradual Rollout** - Implement changes incrementally by team or application
5. **Audit Verification** - Use audit logs to verify all secrets are accessed via new paths

By implementing these namespace and path layout best practices with appropriate policies, you can create a secure, scalable, and manageable Vault implementation that supports your Ansible automation needs while maintaining strong security boundaries.

## Securing Ansible Playbook Executions in Ansible Tower/RHAAP

Ansible Tower (or Red Hat Ansible Automation Platform) provides a centralized platform for managing and executing Ansible playbooks. Securing this platform is critical when integrating with HashiCorp Vault for secrets management.

### Authentication and Authorization Controls

1. **RBAC Implementation** - Configure granular role-based access control:
   - **Organization Admins** - Limited to specific organizational units
   - **Project Managers** - Access to specific projects only
   - **Job Template Executors** - Run-only access to specific job templates
   - **Auditors** - Read-only access for compliance verification

2. **External Authentication** - Integrate with enterprise identity providers:
   - LDAP/Active Directory integration with group synchronization
   - SAML/OAuth for single sign-on capabilities
   - RADIUS for multi-factor authentication

3. **Team-Based Access** - Organize users into teams with specific permissions:

   ```yaml
   # Example Tower/RHAAP RBAC structure
   teams:
     - name: infrastructure_admins
       permissions: [admin_infrastructure_projects]
     - name: application_deployers
       permissions: [execute_application_deployments]
     - name: security_auditors
       permissions: [read_all_job_templates, read_all_inventories]
   ```

### Credential Management

1. **Credential Types** - Create custom credential types for Vault integration:

   ```yaml
   # Example custom credential type for Vault
   credential_types:
     - name: hashicorp_vault
       inputs:
         fields:
           - id: vault_addr
             type: string
             label: Vault Address
           - id: vault_role_id
             type: string
             label: AppRole Role ID
           - id: vault_secret_id
             type: string
             label: AppRole Secret ID
             secret: true
         required: [vault_addr, vault_role_id, vault_secret_id]
       injectors:
         env:
           VAULT_ADDR: "{{ vault_addr }}"
           VAULT_ROLE_ID: "{{ vault_role_id }}"
           VAULT_SECRET_ID: "{{ vault_secret_id }}"
   ```

2. **Credential Isolation** - Separate credentials by environment and purpose:
   - Production credentials accessible only to production teams
   - Development credentials restricted to development teams
   - Credential access audited and logged

3. **Credential Rotation** - Implement automated credential rotation:
   - Schedule regular rotation of Vault authentication credentials
   - Use webhook notifications for credential expiry alerts
   - Implement zero-downtime credential updates

### Secure Job Templates

1. **Execution Environment Isolation** - Use dedicated execution environments:

   ```yaml
   # Example job template with secure execution environment
   job_templates:
     - name: deploy_production_app
       execution_environment: production_secure_ee
       become_enabled: false
       credentials:
         - vault_production
       extra_vars:
         vault_namespace: applications/production
   ```

2. **Privilege Limitation** - Restrict privilege escalation:
   - Disable `become` unless absolutely necessary
   - Use dedicated service accounts with minimal permissions
   - Implement just-in-time privilege escalation

3. **Variable Protection** - Secure sensitive variables:
   - Mark variables containing secrets as `no_log: true`
   - Use survey password fields for sensitive inputs
   - Implement input validation for all variables

4. **Approval Workflows** - Require approvals for sensitive operations:
   - Multi-level approval for production deployments
   - Security team approval for firewall or security group changes
   - Compliance approval for regulated environments

### Vault Integration Best Practices

1. **Dedicated Vault Authentication** - Use AppRole authentication method:
   - One AppRole per job template or workflow
   - Short TTLs for authentication tokens
   - Restricted token policies based on job requirements

2. **Secret Lookup Pattern** - Standardize secret retrieval:

   ```yaml
   # Example of secure Vault lookup in a playbook
   - name: Retrieve database credentials
     ansible.builtin.set_fact:
       db_credentials: "{{ lookup('community.hashi_vault.hashi_vault', 'secret=secret/data/ansible/environments/production/app/database auth_method=approle role_id={{ ansible_env.VAULT_ROLE_ID }} secret_id={{ ansible_env.VAULT_SECRET_ID }}') }}"
     no_log: true
   ```

3. **Secret Scope Limitation** - Restrict secret access scope:
   - Limit Vault token capabilities to read-only
   - Restrict token to specific secret paths
   - Implement path-based policies matching job template purpose

4. **Token Revocation** - Ensure proper token cleanup:
   - Revoke Vault tokens after job completion
   - Implement token TTLs matching expected job duration
   - Use token orphaning for long-running jobs

### Enhanced Security Settings

1. **Network Isolation** - Implement network security controls:
   - Dedicated network segments for automation platform
   - Firewall rules restricting access to Vault
   - TLS for all communications

2. **Instance Groups** - Separate execution by security requirements:
   - Production-only instance groups
   - PCI-compliant instance groups
   - Development/testing instance groups

3. **Container Security** - Secure execution environments:
   - Use CentOS Stream or Fedora Stream base images
   - Regular security scanning of container images
   - Immutable execution environments

## Enhancing Audit Capabilities with Callback Plugins

Callback plugins provide powerful mechanisms for tracking, logging, and auditing Ansible playbook executions, especially when integrated with HashiCorp Vault for secrets management.

### Implementing Audit Callback Plugins

1. **Comprehensive Logging** - Enable detailed logging callbacks:

   ```yaml
   # ansible.cfg configuration
   [defaults]
   callback_whitelist = ansible.posix.profile_tasks, community.general.log_plays, ansible.builtin.timer
   
   [callback_log_plays]
   log_folder = /var/log/ansible/plays
   log_name = ansible-{timestamp}-{playbook}.log
   ```

2. **Custom Security Audit Callback** - Develop specialized audit plugins:

   ```python
   # Example security audit callback plugin
   from ansible.plugins.callback import CallbackBase
   import json
   import logging
   import time
   
   class CallbackModule(CallbackBase):
       CALLBACK_VERSION = 2.0
       CALLBACK_TYPE = 'notification'
       CALLBACK_NAME = 'security_audit'
       
       def __init__(self):
           super(CallbackModule, self).__init__()
           self.logger = logging.getLogger('ansible.security_audit')
           self.logger.setLevel(logging.INFO)
           handler = logging.FileHandler('/var/log/ansible/security_audit.log')
           formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
           handler.setFormatter(formatter)
           self.logger.addHandler(handler)
       
       def v2_playbook_on_task_start(self, task, is_conditional):
           # Log task execution with security context
           self.logger.info(json.dumps({
               'task': task.name,
               'playbook': task._parent._play.name,
               'user': task.get_vars().get('ansible_user', 'unknown'),
               'hosts': [h.name for h in task.get_host_list()],
               'timestamp': time.time(),
               'vault_access': 'hashi_vault' in task.args.get('module_name', '')
           }))
   ```

3. **Vault-Specific Auditing** - Track Vault operations:

   ```python
   # Vault audit callback snippet
   def v2_runner_on_ok(self, result):
       task = result._task
       # Check if task involves Vault operations
       if 'hashi_vault' in task.action or 'lookup(\'hashi_vault' in task.args.get('_raw_params', ''):
           # Extract path accessed without exposing secret values
           vault_path = self._extract_vault_path(task)
           self.logger.info(json.dumps({
               'event': 'vault_access',
               'path': vault_path,
               'host': result._host.name,
               'task': task.name,
               'user': result._task_vars.get('ansible_user', 'unknown'),
               'timestamp': time.time()
           }))
   ```

### Centralized Audit Collection

1. **Log Aggregation** - Forward audit logs to central systems:
   - Configure rsyslog for log forwarding
   - Implement log shipping to SIEM platforms
   - Use structured logging formats (JSON)

2. **Real-time Monitoring** - Implement alerting for suspicious activities:

   ```yaml
   # Example Ansible Tower webhook notification for security events
   notifications:
     - name: security_alert
       notification_type: webhook
       webhook_url: https://security.example.com/alerts
       webhook_headers:
         Content-Type: application/json
         X-Security-Token: "{{ security_token }}"
       webhook_send: always
   ```

3. **Compliance Reporting** - Generate compliance-focused reports:
   - Track secret access patterns
   - Monitor privileged operations
   - Document approval workflows

### Secure Log Management

1. **Log Protection** - Secure audit logs from tampering:
   - Implement WORM (Write Once Read Many) storage
   - Use digital signatures for log integrity
   - Apply strict access controls to log files

2. **Log Retention** - Maintain logs according to compliance requirements:
   - Define retention periods based on data classification
   - Implement automated log rotation and archiving
   - Ensure secure log destruction at end of lifecycle

3. **Sensitive Data Filtering** - Prevent secret exposure in logs:

   ```yaml
   # Example no_log usage in playbooks
   - name: Configure application with database credentials
     ansible.builtin.template:
       src: app_config.j2
       dest: /etc/app/config.yml
       owner: app
       group: app
       mode: '0600'
     vars:
       db_password: "{{ lookup('community.hashi_vault.hashi_vault', 'secret=secret/data/ansible/environments/production/app/database token={{ vault_token }}') }}"
     no_log: true
   ```

### Integration with Security Tools

1. **SIEM Integration** - Forward audit data to security platforms:
   - Splunk integration for comprehensive analysis
   - ELK stack for log visualization
   - Cloud-native security services

2. **Anomaly Detection** - Implement behavioral analysis:
   - Baseline normal automation patterns
   - Alert on unusual secret access
   - Detect unauthorized privilege escalation

3. **Forensic Readiness** - Prepare for security investigations:
   - Maintain detailed execution records
   - Preserve task input and output
   - Document approval chains and authorizations

By implementing these comprehensive auditing capabilities alongside secure Ansible Tower/RHAAP practices, organizations can maintain a strong security posture while enabling the operational benefits of automation with HashiCorp Vault integration.

## Securing Ansible Execution Environments

When using Ansible with Vault in containerized environments, additional security measures should be implemented:

### Execution Environment Security

1. **Minimal Base Images** - Use CentOS Stream or Fedora Stream base images with minimal packages.
2. **Image Scanning** - Implement vulnerability scanning for container images.
3. **Read-Only Filesystems** - Run containers with read-only filesystems where possible.
4. **Non-Root Execution** - Run Ansible processes as non-root users.
5. **Resource Limits** - Set memory and CPU limits to prevent resource exhaustion attacks.

### Example Execution Environment Configuration

```yaml
# execution-environment.yml
---
version: 1
build_arg_defaults:
  EE_BASE_IMAGE: 'quay.io/centos/centos:stream9'

dependencies:
  galaxy: requirements.yml
  python: requirements.txt
  system: bindep.txt

additional_build_steps:
  prepend:
    - RUN pip3 install --upgrade pip setuptools
  append:
    - RUN useradd -m ansible-runner
    - USER ansible-runner
    - WORKDIR /home/ansible-runner
```

## Ansible Vault Integration with HashiCorp Vault

Combine Ansible Vault with HashiCorp Vault for layered security:

### Integration Strategies

1. **Ansible Vault for Playbook Variables** - Encrypt sensitive variables in playbooks.
2. **HashiCorp Vault for Dynamic Secrets** - Use for database credentials, API keys, and certificates.
3. **Vault Lookup Plugin** - Retrieve secrets from HashiCorp Vault during playbook execution.

### Example: Using Ansible Vault with HashiCorp Vault

```yaml
---
# Encrypt the Vault token or AppRole credentials with Ansible Vault
vault_token: !vault |
  $ANSIBLE_VAULT;1.1;AES256
  31613262633339396265663866653063303130316561303338373764633966353131333566623534
  3663633735643132616661656433323333623966396638620a636339303862643163366661336464
  35303234353937323833366536613061633835643539376133383530373938353666333639356239
  6463663939646439390a313736323265656432366236633330313963326365653937323833366130
  3438

# Use HashiCorp Vault lookup with the encrypted token
- name: Retrieve database password from HashiCorp Vault
  ansible.builtin.set_fact:
    db_password: "{{ lookup('community.hashi_vault.hashi_vault', 'secret=secret/ansible/prod/database token={{ vault_token }}') }}"
```

## Dynamic Secrets and Just-in-Time Access

Leverage HashiCorp Vault's dynamic secret capabilities for enhanced security:

### Dynamic Secret Generation

1. **Database Credentials** - Generate temporary database credentials with limited permissions.
2. **Cloud Provider Access** - Create time-limited cloud provider credentials.
3. **SSH Key Rotation** - Generate short-lived SSH keys for server access.

### Example: Dynamic Database Credentials in Ansible

```yaml
---
- name: Generate dynamic PostgreSQL credentials
  ansible.builtin.set_fact:
    db_creds: "{{ lookup('community.hashi_vault.hashi_vault', 'secret=database/creds/readonly token={{ vault_token }}') }}"
  register: db_creds

- name: Connect to database with dynamic credentials
  community.postgresql.postgresql_query:
    login_user: "{{ db_creds.username }}"
    login_password: "{{ db_creds.password }}"
    db: application_db
    query: "SELECT * FROM users LIMIT 10;"
  register: query_result
  no_log: true  # Prevent credentials from appearing in logs
```

## Secret Rotation and Lifecycle Management

Implement automated secret rotation for enhanced security:

### Rotation Strategies

1. **Periodic Rotation** - Schedule regular rotation of static secrets.
2. **Event-Based Rotation** - Rotate secrets after suspicious activities or team changes.
3. **Zero Downtime Rotation** - Implement rotation without service disruption.

### Example: Secret Rotation with Ansible

```yaml
---
- name: Rotate application secrets
  hosts: application_servers
  vars:
    vault_addr: "https://vault.example.com"
  tasks:
    - name: Generate new application secret
      ansible.builtin.set_fact:
        new_secret: "{{ lookup('community.hashi_vault.hashi_vault', 'secret=secret/data/ansible/prod/app/generate token={{ vault_token }}') }}"
      no_log: true

    - name: Update application configuration with new secret
      ansible.builtin.template:
        src: app_config.j2
        dest: /etc/app/config.yml
        owner: app
        group: app
        mode: '0600'
      notify: restart application

    - name: Store new secret in HashiCorp Vault
      community.hashi_vault.vault_write:
        url: "{{ vault_addr }}"
        token: "{{ vault_token }}"
        path: secret/data/ansible/prod/app
        data:
          app_secret: "{{ new_secret }}"
      delegate_to: localhost
      no_log: true

  handlers:
    - name: restart application
      ansible.builtin.service:
        name: app-service
        state: restarted
```

## Audit Logging and Monitoring

Implement comprehensive audit logging for security oversight:

### Audit Strategies

1. **Vault Audit Devices** - Enable file, syslog, or socket audit devices.
2. **Ansible Callback Plugins** - Use plugins to log all Ansible operations.
3. **SIEM Integration** - Forward logs to security information and event management systems.

### Example: Enabling Vault Audit Logging

```hcl
# Enable file audit device
path "sys/audit/file" {
  capabilities = ["sudo", "create", "update"]
}

# Configure file audit device
audit "file" {
  type = "file"
  options = {
    file_path = "/var/log/vault/audit.log"
  }
}
```

### Example: Ansible Playbook with Enhanced Logging

```yaml
---
- name: Configure application with secrets
  hosts: app_servers
  vars:
    ansible_callback_plugins: "/etc/ansible/plugins/callback"
  tasks:
    - name: Retrieve secret from Vault
      ansible.builtin.set_fact:
        app_secret: "{{ lookup('community.hashi_vault.hashi_vault', 'secret=secret/ansible/prod/app token={{ vault_token }}') }}"
      no_log: true
      register: secret_retrieval

    - name: Log secret access (without exposing the secret)
      ansible.builtin.debug:
        msg: "Secret retrieved from path: secret/ansible/prod/app"
        verbosity: 2
```

## Disaster Recovery and Business Continuity

Ensure availability of secrets during outages:

### Disaster Recovery Strategies

1. **Vault HA Configuration** - Deploy Vault in high-availability mode.
2. **Automated Backups** - Schedule regular encrypted backups of Vault data.
3. **Offline Recovery Keys** - Securely store recovery keys for emergency access.
4. **Replication** - Implement performance or disaster recovery replication.

### Example: Vault Backup with Ansible

```yaml
---
- name: Backup Vault configuration
  hosts: vault_servers
  become: true
  tasks:
    - name: Create backup directory
      ansible.builtin.file:
        path: /var/backup/vault
        state: directory
        mode: '0700'
        owner: vault
        group: vault

    - name: Perform Vault snapshot
      ansible.builtin.command: vault operator raft snapshot save /var/backup/vault/vault-{{ ansible_date_time.date }}.snap
      environment:
        VAULT_ADDR: "https://127.0.0.1:8200"
        VAULT_TOKEN: "{{ vault_root_token }}"
      no_log: true

    - name: Encrypt backup
      ansible.builtin.command: gpg --encrypt --recipient vault-backup@example.com /var/backup/vault/vault-{{ ansible_date_time.date }}.snap
      no_log: true

    - name: Copy backup to secure storage
      ansible.builtin.copy:
        src: /var/backup/vault/vault-{{ ansible_date_time.date }}.snap.gpg
        dest: "{{ backup_destination }}"
        remote_src: true
      no_log: true
```

## Conclusion

By implementing RBAC with AD groups, restricting Vault namespace access to specific hosts, integrating with Ansible securely, enforcing strong authentication controls, utilizing SSL certificates, implementing dynamic secrets, automating secret rotation, enabling comprehensive audit logging, and establishing robust disaster recovery procedures, we can ensure the secure usage of HashiCorp Vault for managing secrets in Ansible playbooks. These practices mitigate risks and uphold security compliance within the deployment environment.
