# Must-Gather Log Role - Installation Guide

## Prerequisites

- Ansible Core >= 2.18.4
- Python 3.11+
- OpenShift CLI (`oc`) binary
- Access to OpenShift cluster with admin privileges

## Installation Methods

### Method 1: From Tarball (Recommended)

```bash
# Extract the role
tar -xzf must-gather-log-role-3.0.0.tar.gz -C roles/
mv roles/must-gather-log-role-3.0.0 roles/must_gather_log

# Install Ansible collection dependencies
ansible-galaxy collection install -r roles/must_gather_log/requirements.yml

# Verify installation
ls -la roles/must_gather_log/
```

### Method 2: From Git Repository

```bash
cd roles/
git clone <repository-url> must_gather_log
cd must_gather_log

# Install dependencies
ansible-galaxy collection install -r requirements.yml
```

## Verify Installation

```bash
# Check role structure
ls -la roles/must_gather_log/

# Syntax check with example playbook
ansible-playbook roles/must_gather_log/example-playbook.yml --syntax-check
```

## Next Steps

1. Review the role documentation: `roles/must_gather_log/docs/ROLE-README.md`
2. Check the quick start guide: `roles/must_gather_log/docs/QUICKSTART.md`
3. Customize variables in `roles/must_gather_log/defaults/main.yml`
4. Create your playbook using `roles/must_gather_log/example-playbook.yml` as template
