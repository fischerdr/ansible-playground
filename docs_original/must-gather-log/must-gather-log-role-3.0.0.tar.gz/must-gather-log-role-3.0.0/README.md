# Must-Gather Log Role - Version 3.0.0

Production-ready Ansible role for OpenShift must-gather diagnostics collection with SFTP upload capabilities.

## Package Contents

This distribution contains a complete, standalone Ansible role for collecting OpenShift diagnostics and uploading to Red Hat support cases.

**Version**: 3.0.0
**Release Date**: 2024-12-28
**License**: Apache-2.0

## Quick Start

### Installation

```bash
# Extract role to your Ansible project
tar -xzf must-gather-log-role-3.0.0.tar.gz -C roles/
mv roles/must-gather-log-role-3.0.0 roles/must_gather_log

# Install dependencies
ansible-galaxy collection install kubernetes.core community.hashi_vault
```

### Basic Usage

```yaml
---
- name: Collect and upload must-gather diagnostics
  hosts: localhost
  gather_facts: true

  roles:
    - role: must_gather_log
      vars:
        cluster_name: "prod-ocp-01"
        rh_case: "03123456"
        rh_sftp_user: "user@example.com"
        rh_sftp_token: "token"
```

### Run Playbook

```bash
ansible-playbook playbooks/must-gather-ocp-logs.yml \
  -e cluster_name=prod-ocp-01 \
  -e rh_case=03123456 \
  -e rh_sftp_user=user@example.com \
  -e rh_sftp_token=token
```

## Key Features

- **Modular Architecture**: 9 specialized task files with clean orchestrator pattern (48% code reduction)
- **Automatic SFTP Token Generation**: OAuth2 device authorization flow with no browser required
- **HashiCorp Vault Integration**: Automatic credential retrieval and token storage with expiry tracking
- **Intelligent Credential Management**: Three-tier sourcing (Vault → Auto-generate → Manual)
- **Token Lifecycle Management**: Automatic refresh when expiring within configurable threshold
- **Flexible Operation Modes**: Collect & Upload or Collect-only (no upload)
- **Archive Retention**: Configurable retention policy by days and count
- **Comprehensive Validation**: Pre-execution checks for all requirements
- **Detailed Logging**: Operation logs with timestamps and status tracking

## Requirements

- **Ansible Core**: >= 2.18.4
- **Python**: 3.11+
- **OpenShift CLI**: `oc` binary
- **Collections**:
  - kubernetes.core >= 2.3.0
  - community.hashi_vault >= 3.0.0

## Documentation

- **Quick Start Guide**: `docs/QUICKSTART.md` - Complete getting started with examples
- **Distribution Notes**: `docs/DISTRIBUTION-README.md` - Distribution package details
- **Role Documentation**: `docs/ROLE-README.md` - Complete role documentation with architecture
- **Example Playbook**: `docs/example-playbook.yml` - Production-ready example
- **Package Manifest**: `docs/MANIFEST.txt` - Complete package contents

## Using as Git Repository

This package can be used directly as a standalone Git repository:

```bash
cd must-gather-log-role-3.0.0
git init
git add .
git commit -m "Initial commit: must_gather_log role v3.0.0"
git remote add origin <your-git-url>
git push -u origin main
```

## Support

For issues or questions:

1. Review the role documentation: `docs/ROLE-README.md`
2. Check the CHANGELOG: `CHANGELOG.md`
3. Consult the quick start guide: `docs/QUICKSTART.md`

## Version Information

**Version**: 3.0.0
**Release Date**: 2024-12-28
**Breaking Changes**: None (backward compatible)

### Changelog Highlights

- Modular architecture refactoring (9 specialized task files)
- Automatic SFTP token generation via OAuth2 device authorization
- HashiCorp Vault integration for credential management
- Token expiry checking and automatic refresh
- Custom Ansible module for Red Hat SSO device authorization
- Comprehensive documentation updates
- 48% code reduction in main orchestrator (909 → 470 lines)

See `CHANGELOG.md` for complete version history.
