# Must-Gather Log Role - Distribution Package

Version: 3.0.0
Release Date: 2024-12-28

## Package Contents

- `must-gather-log-role-3.0.0.tar.gz` - Complete standalone Ansible role (35KB)

## What's Included

```text
must-gather-log-role-3.0.0/
├── README.md                    # Complete role documentation
├── INSTALL.md                   # Installation guide
├── CHANGELOG.md                 # Version history
├── LICENSE                      # Apache-2.0 license
├── example-playbook.yml         # Example usage playbook
├── requirements.yml             # Ansible collection dependencies
├── .ansible-lint               # Linting configuration
├── .gitignore                  # Git ignore patterns
├── defaults/main.yml           # Default variables
├── meta/main.yml               # Role metadata
├── group_vars_example.yml      # Example group variables
├── library/                    # Custom modules
│   └── redhat_sso_device_auth.py
├── tasks/                      # Role tasks (9 modular files)
│   ├── main.yml
│   ├── cleanup.yml
│   ├── sftp_credential_management.yml
│   ├── vault_retrieve_sftp_credentials.yml
│   ├── check_token_expiry.yml
│   ├── redhat_sftp_token_generation.yml
│   ├── vault_store_sftp_token.yml
│   ├── must_gather_collection.yml
│   └── must_gather_upload.yml
└── docs/                       # Documentation
    ├── DISTRIBUTION-README.md  # This file
    ├── QUICKSTART.md          # Quick start guide
    ├── ROLE-README.md         # Full role documentation
    ├── MANIFEST.txt           # Package manifest
    └── example-playbook.yml   # Example playbook
```

## Quick Installation

### 1. Extract and Install

```bash
# Extract the role
tar -xzf must-gather-log-role-3.0.0.tar.gz -C roles/
mv roles/must-gather-log-role-3.0.0 roles/must_gather_log

# Install dependencies
ansible-galaxy collection install -r roles/must_gather_log/requirements.yml
```

### 2. Create Playbook

See `example-playbook.yml` at role root for a complete example.

### 3. Run Must-Gather

```bash
ansible-playbook playbooks/must-gather-ocp-logs.yml \
  -e cluster_name=prod-ocp-01 \
  -e rh_case=03123456
```

## Using as Git Repository

This package can be used directly as a standalone Git repository:

```bash
cd must-gather-log-role-3.0.0
git init
git add .
git commit -m "Initial commit: must_gather_log role v3.0.0"
git remote add origin <your-git-url>
git push -u origin main
```

## Documentation

- **Complete Documentation**: `README.md` at role root
- **Installation Guide**: `INSTALL.md`
- **Quick Start Guide**: `docs/QUICKSTART.md`
- **Version History**: `CHANGELOG.md`
- **Example Playbook**: `example-playbook.yml`

## Support

For issues or questions:
1. Review the role README at role root
2. Check the CHANGELOG
3. Consult docs/QUICKSTART.md
