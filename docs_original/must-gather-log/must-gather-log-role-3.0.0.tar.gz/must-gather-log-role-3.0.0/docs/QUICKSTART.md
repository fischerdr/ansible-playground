# Must-Gather Log Role - Quick Start Guide

Version: 3.0.0

## Installation

### 1. Extract the Role

```bash
tar -xzf must-gather-log-role-3.0.0.tar.gz -C roles/
mv roles/must-gather-log-role-3.0.0 roles/must_gather_log
```

### 2. Install Dependencies

```bash
# Install Ansible collections
ansible-galaxy collection install kubernetes.core community.hashi_vault

# Verify oc CLI is available
which oc
```

## Basic Usage

### Scenario 1: Collect and Upload to Red Hat Support Case

You have Red Hat SFTP credentials and a support case number.

```bash
ansible-playbook playbooks/must-gather-ocp-logs.yml \
  -e cluster_name=prod-ocp-01 \
  -e rh_case=03123456 \
  -e rh_sftp_user=user@example.com \
  -e rh_sftp_token=token
```

### Scenario 2: Collect Only (No Upload)

You want to collect must-gather diagnostics but not upload to Red Hat.

```bash
ansible-playbook playbooks/must-gather-ocp-logs.yml \
  -e cluster_name=prod-ocp-01
```

Archives will be preserved in `/tmp/must-gather/archives/`.

### Scenario 3: Auto-Generate SFTP Token

You have Red Hat account credentials and want to automatically generate SFTP tokens.

**Requirements**:
- Red Hat account username and password
- Account MUST NOT have 2FA enabled

```bash
ansible-playbook playbooks/redhat-sftp-token-refresh.yml \
  -e rh_account_username=user@example.com \
  -e rh_account_password=password
```

## Documentation

- **Role Documentation**: `docs/ROLE-README.md` - Complete architecture and configuration
- **Example Playbook**: `docs/example-playbook.yml` - Production-ready example
- **Package Manifest**: `docs/MANIFEST.txt` - Complete package contents
- **Distribution Notes**: `docs/DISTRIBUTION-README.md` - Distribution package details

## Next Steps

1. **Review Full Documentation**: See `docs/ROLE-README.md` for complete architecture and configuration
2. **Customize Variables**: Review `defaults/main.yml` for all configurable options
3. **Test in Development**: Run in dev environment before production deployment

