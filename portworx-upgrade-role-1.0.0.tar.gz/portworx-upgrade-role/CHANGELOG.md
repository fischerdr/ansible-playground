# Changelog

All notable changes to the portworx_upgrade role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-12-10

### Added
- Initial release of portworx_upgrade role
- Comprehensive preflight validation (environment, nodes, pods, cluster health, STC config)
- Operator upgrade with auto-approval and health verification
- ConfigMap and StorageCluster update automation
- Kubernetes API-based monitoring with dual timeout strategy (35min global, 25min per-pod)
- Impatient mode for accelerated storageless node upgrades
- Optimized pxctl patterns using inline shell processing for large clusters (500+ nodes)
- Final validation with pod health, cluster health, and version consistency checks
- Detailed upgrade reporting with timing breakdown
- Support for STC updateStrategy validation (RollingUpdate, maxUnavailable: 1)
- Batch deletion for storageless nodes with configurable batch size
- Safety checks before/between batches in impatient mode
- Resource backup (StorageCluster, ConfigMap, Subscription)
- Tag support for selective phase execution
- Comprehensive documentation with usage examples

### Technical Details
- Passes ansible-lint production profile
- Requires Ansible Core 2.12+
- Requires kubernetes.core collection v2.3.0+
- Supports OpenShift 4.18+
- Supports Portworx 3.4.0+

[1.0.0]: https://github.com/your-org/portworx-upgrade-role/releases/tag/v1.0.0
