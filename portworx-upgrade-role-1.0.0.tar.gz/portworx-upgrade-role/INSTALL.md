# Installation Guide

## Quick Start

### Extract the Role

```bash
# Extract to your Ansible roles directory
tar -xzf portworx-upgrade-role-1.0.0.tar.gz -C roles/
mv roles/portworx-upgrade-role roles/portworx_upgrade
```

Or extract to a custom location:

```bash
# Extract to /opt/ansible/roles
sudo tar -xzf portworx-upgrade-role-1.0.0.tar.gz -C /opt/ansible/roles/
sudo mv /opt/ansible/roles/portworx-upgrade-role /opt/ansible/roles/portworx_upgrade
```

### Install Dependencies

#### Collection Dependencies

```bash
ansible-galaxy collection install -r roles/portworx_upgrade/requirements.yml
```

#### Python Dependencies

```bash
pip install -r roles/portworx_upgrade/requirements.txt
```

### Obtain Version Files

Before running upgrades, download the version file for your target Portworx version:

```bash
# Set variables
export PXVER=3.5.0
export KBVER=$(oc version | awk '/Server Version/ {print $3}')

# Download version file
curl -o roles/portworx_upgrade/files/versions/versions-${PXVER} \
  "https://install.portworx.com/$PXVER/version?kbver=$KBVER"

# Verify file was downloaded
cat roles/portworx_upgrade/files/versions/versions-${PXVER}
```

### Run Example Playbook

```bash
# Copy example playbook to your playbooks directory
cp roles/portworx_upgrade/example-playbook.yml playbooks/px_upgrade.yml

# Run the upgrade
ansible-playbook playbooks/px_upgrade.yml -e portworx_target_version=3.5.0
```

## Alternative Installation Methods

### Method 1: Git Clone (Recommended for Development)

```bash
# Clone directly into roles directory
git clone https://github.com/your-org/portworx-upgrade-role.git roles/portworx_upgrade

# Install dependencies
ansible-galaxy collection install -r roles/portworx_upgrade/requirements.yml
pip install -r roles/portworx_upgrade/requirements.txt
```

### Method 2: Ansible Galaxy (If Published)

```bash
# Install from Ansible Galaxy
ansible-galaxy install your_namespace.portworx_upgrade

# Install collection dependencies
ansible-galaxy collection install kubernetes.core
```

### Method 3: Direct Download

```bash
# Create roles directory
mkdir -p roles

# Download and extract
cd roles
curl -L https://github.com/your-org/portworx-upgrade-role/archive/v1.0.0.tar.gz | tar xz
mv portworx-upgrade-role-1.0.0 portworx_upgrade

# Install dependencies
ansible-galaxy collection install -r portworx_upgrade/requirements.yml
```

## Verification

### Verify Installation

```bash
# Check role directory exists
ls -la roles/portworx_upgrade/

# Verify file structure
tree roles/portworx_upgrade/

# Run syntax check
ansible-playbook playbooks/px_upgrade.yml --syntax-check

# Run ansible-lint
ansible-lint roles/portworx_upgrade/
```

### Test Run (Preflight Only)

```bash
# Run preflight checks only (no changes)
ansible-playbook playbooks/px_upgrade.yml \
  -e portworx_target_version=3.5.0 \
  --tags preflight
```

## Configuration

### Ansible Configuration

Add the role path to your `ansible.cfg`:

```ini
[defaults]
roles_path = ./roles:/usr/share/ansible/roles
collections_path = ./collections:/usr/share/ansible/collections
```

### Environment Variables

Set these environment variables for easier usage:

```bash
# Cluster identification
export CLUSTER_NAME=prod-cluster-01

# Work directory
export WORK_DIR=/var/lib/ansible/work

# Kubeconfig
export KUBECONFIG=/path/to/kubeconfig
```

## Troubleshooting

### Missing Collections

If you see `ERROR! couldn't resolve module/action 'kubernetes.core.k8s'`:

```bash
ansible-galaxy collection install kubernetes.core
```

### Missing Python Libraries

If you see `ERROR! couldn't resolve module/action 'kubernetes.core.k8s_info'`:

```bash
pip install kubernetes PyYAML
```

### Version File Not Found

If you see `Version file not found`:

```bash
# Download version file as shown above
export PXVER=3.5.0
export KBVER=$(oc version | awk '/Server Version/ {print $3}')
curl -o roles/portworx_upgrade/files/versions/versions-${PXVER} \
  "https://install.portworx.com/$PXVER/version?kbver=$KBVER"
```

### Permission Denied

If you see permission errors, ensure you have cluster admin access:

```bash
oc auth can-i '*' '*' --all-namespaces
```

## Next Steps

After installation:

1. Review [README.md](README.md) for detailed role documentation
2. Customize variables in your playbook as needed
3. Review [example-playbook.yml](example-playbook.yml) for usage patterns
4. Test in development environment first
5. Review [CHANGELOG.md](CHANGELOG.md) for version history

## Support

For issues during installation:

1. Check [README.md](README.md) troubleshooting section
2. Verify all dependencies are installed
3. Check Ansible and collection versions
4. Review role directory structure
5. Open an issue on GitHub with full error output
