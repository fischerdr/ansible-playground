# Ansible Role: portworx_upgrade

Production-ready Ansible role for automated Portworx cluster upgrades on OpenShift 4.18+.

## Overview

This role automates the upgrade of Portworx storage clusters with comprehensive validation, operator-controlled rolling upgrades, intelligent monitoring, and optional acceleration for storageless nodes.

## Key Features

- **Comprehensive Preflight Validation**: Validates nodes, pods, cluster health, and StorageCluster configuration
- **Operator-Controlled Rolling Upgrade**: Monitors automatic one-pod-at-a-time upgrades
- **Dual Timeout Strategy**: 35-minute global inactivity timeout, 25-minute per-pod timeout
- **Kubernetes API-Based Monitoring**: Efficient pod tracking without pxctl overhead
- **Optimized for Large Clusters**: Inline shell processing returns only results, not full pxctl output
- **Impatient Mode**: Optional batch deletion for accelerated storageless node upgrades
- **Safety Checks**: Cluster health verification before/during/after upgrade
- **Detailed Reporting**: Comprehensive upgrade summary with timing breakdown

## Requirements

### Ansible Version
- Ansible Core 2.12+

### Collections
- `kubernetes.core` (v2.3.0+)

### Python Dependencies
- `kubernetes` Python library
- `PyYAML`

### Platform
- OpenShift 4.18+
- Portworx 3.4.0+ (source version)
- RHEL/CentOS 8 or 9 (execution environment)

### Permissions
- Cluster admin access or equivalent permissions for:
  - Reading/patching StorageCluster CRDs
  - Managing ConfigMaps in portworx namespace
  - Managing operator InstallPlans
  - Executing commands in pods

## Installation

### From Git Repository

```bash
# Clone the repository
git clone https://github.com/your-org/portworx-upgrade-role.git roles/portworx_upgrade

# Or install via ansible-galaxy (if published)
ansible-galaxy install your_namespace.portworx_upgrade
```

### Collection Requirements

Install required collections:

```bash
ansible-galaxy collection install kubernetes.core
```

## Role Variables

### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `portworx_target_version` | Target Portworx OCI version | `"3.5.0"` |

### Timeout Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `portworx_pod_upgrade_timeout` | `1500` | Seconds (25 min) for single pod upgrade |
| `portworx_global_inactivity_timeout` | `2100` | Seconds (35 min) for no upgrade activity |
| `portworx_pod_check_interval` | `10` | Seconds between pod status checks |

### Impatient Mode (Optional)

| Variable | Default | Description |
|----------|---------|-------------|
| `portworx_impatient_mode` | `false` | Enable batch deletion of storageless pods |
| `portworx_impatient_batch_size` | `5` | Number of storageless pods per batch |
| `portworx_impatient_wait_time` | `300` | Seconds to wait for batch recovery |
| `portworx_impatient_batch_delay` | `30` | Seconds between batches |
| `portworx_impatient_safety_checks` | `true` | Perform health checks before/between batches |

### Logging and Reporting

| Variable | Default | Description |
|----------|---------|-------------|
| `portworx_detailed_logging` | `true` | Enable detailed version transition logging |
| `portworx_create_summary` | `true` | Generate upgrade summary report |
| `portworx_work_dir` | `/tmp/ansible-workdir` | Base working directory |
| `portworx_report_dir` | `{{ portworx_work_dir }}/portworx-upgrade` | Report output directory |

### Preflight Behavior

| Variable | Default | Description |
|----------|---------|-------------|
| `portworx_fail_on_unhealthy_pods` | `true` | Fail if pods are unhealthy |
| `portworx_fail_on_degraded_cluster` | `true` | Fail if cluster is degraded |
| `portworx_fail_on_invalid_updatestrategy` | `true` | Fail if STC updateStrategy is incorrect |

See [defaults/main.yml](defaults/main.yml) for complete variable list.

## Version Files

Before running upgrades, obtain the version file for your target version:

```bash
export PXVER=3.5.0
export KBVER=$(oc version | awk '/Server Version/ {print $3}')
curl -o files/versions/versions-${PXVER} \
  "https://install.portworx.com/$PXVER/version?kbver=$KBVER"
```

See [files/versions/README.md](files/versions/README.md) for details.

## Example Playbook

### Basic Upgrade

```yaml
---
- name: Upgrade Portworx cluster
  hosts: localhost
  gather_facts: true

  vars:
    portworx_target_version: "3.5.0"

  roles:
    - portworx_upgrade
```

### Upgrade with Impatient Mode

```yaml
---
- name: Upgrade Portworx cluster with acceleration
  hosts: localhost
  gather_facts: true

  vars:
    portworx_target_version: "3.5.0"
    portworx_impatient_mode: true
    portworx_impatient_batch_size: 7

  roles:
    - portworx_upgrade
```

### Conservative Upgrade with Detailed Logging

```yaml
---
- name: Conservative Portworx upgrade
  hosts: localhost
  gather_facts: true

  vars:
    portworx_target_version: "3.5.0"
    portworx_operator_auto_approve: false
    portworx_detailed_logging: true
    portworx_impatient_mode: false

  roles:
    - portworx_upgrade
```

## Usage

### Command Line

```bash
# Basic upgrade
ansible-playbook site.yml -e portworx_target_version=3.5.0

# With impatient mode
ansible-playbook site.yml \
  -e portworx_target_version=3.5.0 \
  -e portworx_impatient_mode=true

# Preflight checks only
ansible-playbook site.yml \
  -e portworx_target_version=3.5.0 \
  --tags preflight

# Skip operator upgrade
ansible-playbook site.yml \
  -e portworx_target_version=3.5.0 \
  -e portworx_skip_operator_upgrade=true
```

## Tags

- `preflight` - Pre-flight validation only
- `validation` - Pre-flight validation only
- `upgrade` - Upgrade phases (operator, configmap, components, storagecluster)
- `operator` - Operator upgrade only
- `configmap` - ConfigMap update only
- `components` - Component updates only
- `storagecluster` - StorageCluster update only
- `monitor` - Monitoring phase only
- `validate` - Final validation only
- `final` - Final validation only
- `report` - Report generation only

## Upgrade Phases

The role executes in 8 phases:

1. **Pre-flight Validation** - Validates environment, nodes, pods, cluster health, STC config
2. **Operator Upgrade** - Upgrades Portworx operator (optional, can be skipped)
3. **ConfigMap Update** - Updates px-versions ConfigMap with target version
4. **Component Updates** - Patches StorageCluster with autoUpdateComponents
5. **StorageCluster Update** - Triggers rolling upgrade by updating image field
6. **Monitoring** - Monitors automatic rolling upgrade with timeout detection
7. **Final Validation** - Validates all pods upgraded, cluster healthy, versions consistent
8. **Reporting** - Generates comprehensive upgrade summary

## How It Works

### Operator-Controlled Upgrade

Once the StorageCluster image field is updated, the Portworx operator automatically handles the rolling upgrade one pod at a time (enforced by `maxUnavailable: 1`). The role **monitors** this process, it does not control which pod upgrades next.

### Monitoring Strategy

The role uses Kubernetes API to watch pod image changes:
- Tracks pods with new image (Running + Ready)
- Tracks pods with old image (needing upgrade)
- Tracks pods actively upgrading (Terminating, Pending, ContainerCreating)
- Tracks pods with new image but not yet Ready

### Timeout Detection

Two critical timeouts:

1. **Global Inactivity Timeout (35 minutes)**: If NO activity detected for 35 minutes, the operator is stuck → FAIL
2. **Per-Pod Timeout (25 minutes)**: If a single pod takes >25 minutes to upgrade → WARNING

Activity = any pod in Terminating, Pending, ContainerCreating, or new image but not Ready.

### Impatient Mode

For large clusters with many storageless nodes, impatient mode can accelerate upgrades:

1. Waits for all storage nodes to upgrade first
2. Verifies cluster is operational
3. Batch-deletes storageless pods (5-7 at a time)
4. Waits for batch to recover before next batch
5. Performs safety checks between batches

**WARNING**: Impatient mode is aggressive. Use with caution.

## Optimization for Large Clusters

### Inline Shell Processing

All pxctl commands use inline shell processing to return **only results**, not full output:

```yaml
# Returns only: "operational" or "degraded"
kubernetes.core.k8s_exec:
  command: |
    /bin/bash -c "
    export PXCTL_AUTH_TOKEN='{{ token }}' &&
    pxctl status | grep -q 'PX is operational' && echo 'operational' || echo 'degraded'
    "
```

This prevents memory/performance issues with 500+ node clusters.

## Troubleshooting

### Upgrade Stuck

If upgrade times out:

1. Check operator logs:
   ```bash
   oc logs -n portworx -l name=portworx-operator
   ```

2. Check StorageCluster events:
   ```bash
   oc describe stc -n portworx
   ```

3. Check for stuck pods:
   ```bash
   oc get pods -n portworx -l name=portworx
   ```

4. Review pxctl status:
   ```bash
   oc exec -n portworx <pod-name> -- /opt/pwx/bin/pxctl status
   ```

### Preflight Failures

- **Unhealthy pods**: Troubleshoot pod issues before upgrade
- **Degraded cluster**: Check `pxctl status` for offline nodes
- **Invalid updateStrategy**: Verify STC has correct updateStrategy configuration
- **Version file missing**: Download version file as described above

### Impatient Mode Issues

- **Cluster degraded after batch**: Safety checks will stop impatient mode
- **Batch timeout**: Increase `portworx_impatient_wait_time`
- **Storage nodes not upgraded**: Impatient mode requires all storage nodes upgraded first

## Reports

Upgrade reports are saved to `{{ portworx_report_dir }}`:

- `upgrade-summary-<timestamp>.txt` - Comprehensive upgrade summary
- `backups/pre-upgrade-stc-<timestamp>.yaml` - Pre-upgrade StorageCluster backup
- `backups/pre-upgrade-configmap-<timestamp>.yaml` - Pre-upgrade ConfigMap backup
- `backups/pre-upgrade-subscription-<timestamp>.yaml` - Pre-upgrade Subscription backup

## Testing

### Syntax Check

```bash
ansible-playbook --syntax-check site.yml
```

### Ansible-lint

```bash
ansible-lint .
```

### Dry Run

```bash
ansible-playbook site.yml -e portworx_target_version=3.5.0 --check
```

### Tag-based Testing

```bash
# Test preflight only
ansible-playbook site.yml -e portworx_target_version=3.5.0 --tags preflight

# Test upgrade phases only (no monitoring)
ansible-playbook site.yml -e portworx_target_version=3.5.0 --tags upgrade --check
```

## License

MIT

## Author

Enterprise Platform Team

## Support

For issues and questions, please open an issue in the GitHub repository.
