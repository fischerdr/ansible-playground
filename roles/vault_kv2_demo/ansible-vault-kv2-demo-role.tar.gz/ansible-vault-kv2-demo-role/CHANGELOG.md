# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-01-10

### Added
- Initial release of vault_kv2_demo role
- Complete Kubernetes authentication setup with service accounts
- Vault namespace configuration (Enterprise feature with OSS fallback)
- Kubernetes authentication method setup in Vault
- KV2 secret engine configuration and management
- Example secrets for applications, infrastructure, and certificates
- Secret write, read, and validation operations
- End-to-end authentication testing
- Optional cleanup functionality
- Comprehensive documentation with examples and troubleshooting
- GitHub Actions workflow for ansible-lint
- MIT License

### Features
- Uses community.hashi_vault collection modules exclusively
- Secure by default (validate_certs: true, no_log: true)
- Comprehensive error handling with block/rescue/always
- Tag-based execution for selective operations
- Retry logic for Vault and Kubernetes operations
- FQCN and lowercase boolean conventions
- Idempotent operations throughout

### Documentation
- Main README with quick start guide
- Detailed role README with 500+ lines
- Contributing guidelines
- Code of conduct
- Comparison with legacy approaches
- Troubleshooting guide

### Collections Required
- community.hashi_vault >= 6.0.0
- kubernetes.core >= 3.0.0
- ansible.posix >= 1.5.0
- ansible.utils >= 3.0.0

### Compatibility
- Ansible Core 2.18+
- Python 3.11+
- HashiCorp Vault OSS and Enterprise
- Kubernetes 1.24+

[1.0.0]: https://github.com/yourusername/ansible-vault-kv2-demo-role/releases/tag/v1.0.0
