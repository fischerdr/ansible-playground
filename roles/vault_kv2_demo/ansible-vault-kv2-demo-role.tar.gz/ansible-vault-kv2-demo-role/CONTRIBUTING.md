# Contributing to Ansible Vault KV2 Demo Role

Thank you for your interest in contributing! This document provides guidelines for contributing to this project.

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow

## How to Contribute

### Reporting Issues

When reporting issues, please include:
- Ansible version
- Python version
- Operating system
- Vault version (OSS or Enterprise)
- Kubernetes version
- Complete error messages
- Steps to reproduce

### Submitting Changes

1. **Fork the repository**
   ```bash
   git clone https://github.com/yourusername/ansible-vault-kv2-demo-role.git
   cd ansible-vault-kv2-demo-role
   ```

2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make your changes**
   - Follow the coding standards below
   - Add tests if applicable
   - Update documentation

4. **Test your changes**
   ```bash
   # Syntax check
   ansible-playbook playbooks/vault_kv2_demo.yml --syntax-check

   # Lint check
   ansible-lint
   yamllint .

   # Functional test (if you have a test environment)
   ansible-playbook playbooks/vault_kv2_demo.yml --check
   ```

5. **Commit your changes**
   ```bash
   git add .
   git commit -m "Add feature: description of changes"
   ```

6. **Push and create a Pull Request**
   ```bash
   git push origin feature/your-feature-name
   ```

## Coding Standards

### Ansible Best Practices

**Required:**
- ✅ Always use FQCN (Fully Qualified Collection Names)
  ```yaml
  # Good
  - name: Example task
    ansible.builtin.debug:
      msg: "Hello"

  # Bad
  - name: Example task
    debug:
      msg: "Hello"
  ```

- ✅ Use lowercase `true`/`false` for booleans
  ```yaml
  # Good
  validate_certs: true

  # Bad
  validate_certs: True
  ```

- ✅ Use `no_log: true` for sensitive operations
  ```yaml
  - name: Login to Vault
    community.hashi_vault.vault_login:
      token: "{{ vault_token }}"
    no_log: true
  ```

- ✅ Use `block`/`rescue`/`always` for error handling
  ```yaml
  - name: Perform operation
    block:
      - name: Main task
        # ... task definition
    rescue:
      - name: Handle error
        # ... error handling
    always:
      - name: Cleanup
        # ... cleanup tasks
  ```

- ✅ Use meaningful task names
  ```yaml
  # Good
  - name: Create Kubernetes ServiceAccount for Vault authentication

  # Bad
  - name: Create SA
  ```

- ✅ Validate inputs with `assert`
  ```yaml
  - name: Validate required variables
    ansible.builtin.assert:
      that:
        - variable is defined
        - variable | length > 0
      fail_msg: "variable must be defined and non-empty"
  ```

### Variable Naming

- Use consistent prefixes for all role variables
- Format: `rolename_category_specific_name`
- Example: `vault_kv2_demo_vault_addr`

### Documentation

**Every change must include:**
- Updated README.md if behavior changes
- Updated variable documentation in defaults/main.yml
- Inline comments for complex logic
- Example usage if adding new features

### Security

**Always:**
- Set `validate_certs: true` for HTTPS connections
- Use `no_log: true` for sensitive data
- Never commit credentials or tokens
- Use Ansible Vault for secrets in examples

## Testing Checklist

Before submitting a PR, ensure:

- [ ] Syntax check passes
- [ ] ansible-lint passes with no errors
- [ ] yamllint passes
- [ ] All tasks use FQCN
- [ ] All booleans are lowercase
- [ ] Sensitive operations have `no_log: true`
- [ ] Error handling uses `block`/`rescue`/`always`
- [ ] Documentation is updated
- [ ] README examples work
- [ ] No credentials in code

## Pull Request Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Refactoring

## Testing
- [ ] Syntax check passed
- [ ] ansible-lint passed
- [ ] yamllint passed
- [ ] Functional testing completed

## Checklist
- [ ] FQCN used throughout
- [ ] Lowercase booleans
- [ ] `no_log` for sensitive ops
- [ ] Documentation updated
- [ ] Examples tested
```

## Questions?

Feel free to open an issue for:
- Questions about contributing
- Clarification on standards
- Feature discussions

Thank you for contributing!
