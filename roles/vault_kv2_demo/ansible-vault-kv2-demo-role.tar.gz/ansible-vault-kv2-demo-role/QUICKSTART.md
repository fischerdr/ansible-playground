# Quick Start Guide

Get up and running with the Ansible Vault KV2 Demo Role in minutes!

## Prerequisites

- Ansible 2.18+
- Python 3.11+
- Access to a HashiCorp Vault server
- Access to a Kubernetes cluster
- Vault root or admin token

## Installation

### 1. Extract the Archive

```bash
tar -xzf ansible-vault-kv2-demo-role.tar.gz
cd ansible-vault-kv2-demo-role
```

### 2. Install Dependencies

```bash
# Using make
make install

# Or manually
ansible-galaxy collection install -r requirements.yml
```

### 3. Configure Your Environment

Copy and customize the example inventory:

```bash
cp inventory/group_vars/all.yml.example inventory/group_vars/all.yml
```

Edit `inventory/group_vars/all.yml` with your values:

```yaml
vault_kv2_demo_vault_addr: "https://your-vault.example.com:8200"
vault_kv2_demo_root_token: "hvs.your-token-here"
vault_kv2_demo_k8s_host: "https://your-k8s-api:6443"
vault_kv2_demo_vault_namespace: "demo"  # or "" for OSS
```

**Security Note**: Encrypt your token with Ansible Vault:

```bash
ansible-vault encrypt_string 'hvs.your-token' --name 'vault_kv2_demo_root_token'
```

## Running the Demo

### Option 1: Using Make (Recommended)

```bash
# Run with values from inventory
make run

# Run with command-line overrides
make run ARGS="-e vault_kv2_demo_vault_addr=https://vault.local:8200"

# Check syntax first
make syntax-check

# Dry run (check mode)
make run-check

# Verbose output
make run-verbose
```

### Option 2: Direct Ansible Command

```bash
ansible-playbook playbooks/vault_kv2_demo.yml \
  -e vault_kv2_demo_vault_addr=https://vault.example.com:8200 \
  -e vault_kv2_demo_root_token=hvs.your-token \
  -e vault_kv2_demo_k8s_host=https://k8s.example.com:6443
```

### Option 3: With Inventory File

```bash
ansible-playbook playbooks/vault_kv2_demo.yml -i inventory/hosts.yml
```

## What Happens When You Run It?

The role will:

1. ✅ **Validate** all required variables
2. ✅ **Create** Kubernetes ServiceAccount and ClusterRoleBinding
3. ✅ **Setup** Vault namespace (if using Enterprise)
4. ✅ **Enable** Kubernetes authentication in Vault
5. ✅ **Configure** KV2 secret engine
6. ✅ **Write** 5 example secrets to different paths
7. ✅ **Read** and validate all secrets
8. ✅ **Test** end-to-end authentication flow

## Expected Output

You'll see colored output with progress indicators:

```
PLAY [Demonstrate HashiCorp Vault KV2 integration] ****************************

TASK [vault_kv2_demo : Display role execution banner] *************************
ok: [localhost] =>
  ========================================
  Vault KV2 Demo Role - Starting Execution
  ========================================
  Vault Address: https://vault.example.com:8200
  Vault Namespace: demo
  K8s Namespace: default
  KV2 Mount: demo-secrets
  ========================================

...

PLAY RECAP *********************************************************************
localhost : ok=45  changed=10  unreachable=0  failed=0  skipped=2  rescued=0
```

## Verifying the Results

### Check Vault Resources

```bash
# List the KV2 mount
vault secrets list

# List secrets in the demo mount
vault kv list demo-secrets

# Read a secret
vault kv get demo-secrets/applications/webapp
```

### Check Kubernetes Resources

```bash
# Check ServiceAccount
kubectl get sa vault-auth-demo -n default

# Check ClusterRoleBinding
kubectl get clusterrolebinding vault-tokenreview-vault-auth-demo

# Check token Secret
kubectl get secret vault-auth-demo-token -n default
```

## Running Specific Operations

### Only Setup (No Cleanup)

```bash
ansible-playbook playbooks/vault_kv2_demo.yml --skip-tags cleanup
```

### Only Write Secrets

```bash
make run-tags TAGS=kv2,write
```

### Only Test Authentication

```bash
make run-tags TAGS=test
```

## Cleanup

Remove all created resources:

```bash
# Using make
make cleanup

# Or with ansible-playbook
ansible-playbook playbooks/vault_kv2_demo.yml \
  -e vault_kv2_demo_cleanup=true \
  --tags cleanup
```

## Customizing Secrets

Edit the playbook or create a vars file:

```yaml
# custom-secrets.yml
vault_kv2_demo_secrets:
  - path: "myapp/production"
    data:
      database_host: "prod-db.example.com"
      database_password: "secure_prod_password"
      api_endpoint: "https://api.prod.example.com"

  - path: "myapp/staging"
    data:
      database_host: "staging-db.example.com"
      database_password: "secure_staging_password"
      api_endpoint: "https://api.staging.example.com"
```

Then run with:

```bash
ansible-playbook playbooks/vault_kv2_demo.yml -e @custom-secrets.yml
```

## Troubleshooting

### Vault Connection Issues

```bash
# Test connectivity
curl -k https://your-vault.example.com:8200/v1/sys/health

# Verify SSL certificate
openssl s_client -connect your-vault.example.com:8200 -showcerts
```

### Authentication Failures

```bash
# Test your Vault token
export VAULT_ADDR=https://your-vault.example.com:8200
export VAULT_TOKEN=hvs.your-token
vault token lookup

# Check token permissions
vault token capabilities sys/mounts
vault token capabilities sys/auth
```

### Kubernetes Issues

```bash
# Verify kubectl access
kubectl cluster-info
kubectl auth can-i create serviceaccount
kubectl auth can-i create clusterrolebinding

# Check API server address
kubectl config view --minify -o jsonpath='{.clusters[0].cluster.server}'
```

### Common Errors

**"Permission denied"**
- Ensure your Vault token has admin/root permissions
- Check token TTL hasn't expired

**"Connection refused"**
- Verify Vault address is correct and accessible
- Check firewall rules

**"Invalid namespace"**
- Set `vault_kv2_demo_vault_namespace: ""` for Vault OSS
- Verify namespace exists in Vault Enterprise

## Next Steps

1. **Read the full documentation**: [README.md](README.md)
2. **Explore the role**: [roles/vault_kv2_demo/README.md](roles/vault_kv2_demo/README.md)
3. **Customize for your needs**: Edit defaults and create custom secrets
4. **Integrate with your projects**: Use as a template for your own roles

## Getting Help

- Review the [troubleshooting guide](roles/vault_kv2_demo/README.md#troubleshooting)
- Check [CONTRIBUTING.md](CONTRIBUTING.md) for contribution guidelines
- Open an issue on GitHub

## Development Commands

```bash
# Lint your changes
make lint

# Run syntax check
make syntax-check

# Run all tests
make test

# Clean temporary files
make clean
```

Happy automating! 🚀
