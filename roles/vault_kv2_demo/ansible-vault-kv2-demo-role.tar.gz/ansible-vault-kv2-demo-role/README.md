# Ansible Vault KV2 Demo Role

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Ansible](https://img.shields.io/badge/Ansible-2.18%2B-blue.svg)](https://www.ansible.com/)

A comprehensive demonstration role for HashiCorp Vault integration with Kubernetes authentication and KV2 secret engine operations, designed for enterprise Ansible Automation Platform environments.

## Overview

This role provides a complete, production-ready example of integrating HashiCorp Vault with Kubernetes using modern Ansible best practices. It demonstrates:

- **Vault Namespace Configuration** - Enterprise namespace management with OSS fallback
- **Kubernetes Authentication** - Complete K8s auth method setup with service accounts
- **KV2 Secret Engine** - Enable, configure, and manage KV version 2 secrets
- **Secret Operations** - Write, read, validate, and list secrets
- **Authentication Testing** - Full end-to-end authentication flow demonstration
- **Proper Module Usage** - Exclusively uses `community.hashi_vault` collection

## Key Features

✅ **Uses community.hashi_vault Collection**
- Proper abstraction over Vault API
- Built-in support for namespaces and authentication methods
- Better error handling and validation

✅ **Enterprise-Ready**
- Ansible Automation Platform compatible
- Execution Environment ready
- Comprehensive error handling with `block`/`rescue`/`always`
- Follows FQCN and lowercase boolean conventions

✅ **Secure by Default**
- `validate_certs: true` for all HTTPS connections
- `no_log: true` for sensitive operations
- Proper token management and cleanup

✅ **Well-Documented**
- Comprehensive README with examples
- Inline documentation for all variables
- Troubleshooting guidance

## Quick Start

### Prerequisites

- Ansible 2.18+
- Python 3.11+
- HashiCorp Vault server (OSS or Enterprise)
- Kubernetes cluster with appropriate RBAC permissions
- Vault root/admin token

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/ansible-vault-kv2-demo-role.git
cd ansible-vault-kv2-demo-role

# Install required collections
ansible-galaxy collection install -r requirements.yml
```

### Basic Usage

```bash
# Customize the playbook with your values
ansible-playbook playbooks/vault_kv2_demo.yml \
  -e vault_kv2_demo_vault_addr=https://your-vault.com:8200 \
  -e vault_kv2_demo_root_token=hvs.your-token \
  -e vault_kv2_demo_k8s_host=https://your-k8s-api:6443
```

## Documentation

For complete documentation, see [roles/vault_kv2_demo/README.md](roles/vault_kv2_demo/README.md)

Key sections:
- [Requirements](roles/vault_kv2_demo/README.md#requirements)
- [Role Variables](roles/vault_kv2_demo/README.md#role-variables)
- [Example Playbooks](roles/vault_kv2_demo/README.md#example-playbook)
- [What This Role Does](roles/vault_kv2_demo/README.md#what-this-role-does)
- [Troubleshooting](roles/vault_kv2_demo/README.md#troubleshooting)

## Project Structure

```
ansible-vault-kv2-demo-role/
├── roles/
│   └── vault_kv2_demo/          # Main role
│       ├── defaults/             # Default variables
│       ├── tasks/                # Task files
│       ├── meta/                 # Role metadata
│       └── README.md             # Detailed role documentation
├── playbooks/
│   └── vault_kv2_demo.yml       # Example playbook
├── requirements.yml              # Ansible collection dependencies
├── ansible.cfg                   # Ansible configuration
├── .ansible-lint                 # Ansible-lint configuration
└── README.md                     # This file
```

## What Gets Created

When you run this role, it creates:

1. **Kubernetes Resources**:
   - ServiceAccount for Vault authentication
   - ClusterRoleBinding for token review
   - Secret containing service account token

2. **Vault Configuration**:
   - Namespace (Enterprise only)
   - Kubernetes authentication method
   - Vault policy for secret access
   - Vault role bound to K8s service account

3. **KV2 Secret Engine**:
   - Enabled and configured KV2 engine
   - Example secrets in multiple paths
   - Validated secret read operations

4. **Testing**:
   - Complete authentication flow demonstration
   - Secret access validation

## Example Playbook

```yaml
---
- name: Demonstrate Vault KV2 integration
  hosts: localhost
  gather_facts: false

  vars:
    vault_kv2_demo_vault_addr: "https://vault.example.com:8200"
    vault_kv2_demo_root_token: "{{ vault_root_token }}"
    vault_kv2_demo_k8s_host: "https://kubernetes.default.svc:443"
    vault_kv2_demo_vault_namespace: "demo"

  roles:
    - vault_kv2_demo
```

## Configuration

### Required Variables

```yaml
vault_kv2_demo_vault_addr: "https://vault.example.com:8200"
vault_kv2_demo_root_token: "hvs.your-token"
vault_kv2_demo_k8s_host: "https://kubernetes.default.svc:443"
```

### Optional Customization

```yaml
# Vault namespace (Enterprise)
vault_kv2_demo_vault_namespace: "demo"

# Kubernetes configuration
vault_kv2_demo_k8s_namespace: "default"
vault_kv2_demo_service_account_name: "vault-auth-demo"

# KV2 engine settings
vault_kv2_demo_kv2_mount_path: "demo-secrets"
vault_kv2_demo_kv2_max_versions: 10

# Custom secrets
vault_kv2_demo_secrets:
  - path: "myapp/config"
    data:
      db_host: "postgres.example.com"
      db_password: "secure_password"
```

## Tags

Execute specific parts of the role using tags:

```bash
# Only create Kubernetes resources
ansible-playbook playbooks/vault_kv2_demo.yml --tags kubernetes

# Only work with KV2 secrets
ansible-playbook playbooks/vault_kv2_demo.yml --tags kv2,write,read

# Run cleanup
ansible-playbook playbooks/vault_kv2_demo.yml --tags cleanup
```

Available tags:
- `validation` - Input validation
- `kubernetes`, `serviceaccount` - K8s resource management
- `vault`, `namespace`, `auth` - Vault configuration
- `kv2`, `secrets`, `write`, `read` - Secret operations
- `test` - Authentication testing
- `cleanup` - Resource cleanup

## Testing

```bash
# Syntax check
ansible-playbook playbooks/vault_kv2_demo.yml --syntax-check

# Dry run
ansible-playbook playbooks/vault_kv2_demo.yml --check

# Run with increased verbosity
ansible-playbook playbooks/vault_kv2_demo.yml -vvv
```

## Cleanup

To remove all created resources:

```bash
ansible-playbook playbooks/vault_kv2_demo.yml \
  -e vault_kv2_demo_cleanup=true \
  --tags cleanup
```

## Comparison with Legacy Approaches

This role demonstrates modern best practices compared to legacy implementations:

| Feature | Legacy Approach | This Role |
|---------|----------------|-----------|
| Vault API | Direct `ansible.builtin.uri` calls | `community.hashi_vault` modules |
| SSL Validation | Often disabled | Always enabled by default |
| Error Handling | Manual status checks | `block`/`rescue`/`always` |
| Namespaces | Manual header construction | Native parameter support |
| Documentation | Inline comments | Comprehensive README |

## Troubleshooting

### Vault Connection Issues

```bash
# Test Vault connectivity
curl -k https://your-vault.com:8200/v1/sys/health

# Verify token
vault login hvs.your-token
vault token lookup
```

### Kubernetes Issues

```bash
# Verify service account
kubectl get sa vault-auth-demo -n default
kubectl get secret vault-auth-demo-token -n default

# Check ClusterRoleBinding
kubectl get clusterrolebinding vault-tokenreview-vault-auth-demo
```

### Common Errors

See the [Troubleshooting section](roles/vault_kv2_demo/README.md#troubleshooting) in the role README for detailed solutions.

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

Please ensure:
- All tasks use FQCN
- Booleans are lowercase (`true`/`false`)
- Sensitive operations have `no_log: true`
- Error handling uses `block`/`rescue`/`always`
- Documentation is updated

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Author

Created as a demonstration of modern Ansible and HashiCorp Vault integration patterns for enterprise environments.

## Support

For issues, questions, or contributions:
- Open an issue on GitHub
- Review the [detailed role documentation](roles/vault_kv2_demo/README.md)
- Check the [troubleshooting guide](roles/vault_kv2_demo/README.md#troubleshooting)

## References

- [HashiCorp Vault Documentation](https://developer.hashicorp.com/vault/docs)
- [Vault Kubernetes Auth Method](https://developer.hashicorp.com/vault/docs/auth/kubernetes)
- [Vault KV Secrets Engine v2](https://developer.hashicorp.com/vault/docs/secrets/kv/kv-v2)
- [community.hashi_vault Collection](https://docs.ansible.com/ansible/latest/collections/community/hashi_vault/)
- [kubernetes.core Collection](https://docs.ansible.com/ansible/latest/collections/kubernetes/core/)
- [Ansible Best Practices](https://docs.ansible.com/ansible/latest/tips_tricks/ansible_tips_tricks.html)
